❗DON'T DELETE ANY FILES OTHERWISE IT WON'T WORK❗

# How to #
Run "Vape Lite.exe", wait for GUI to load, keep "Vape Lite.exe" open, enjoy!